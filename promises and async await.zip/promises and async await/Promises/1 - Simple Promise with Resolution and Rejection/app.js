const btn = document.querySelector('#triggerPromise');

console.log(btn);

btn.addEventListener('click', function () {
  let checkBoxPromise = new Promise((resolve, reject) => {});
});
